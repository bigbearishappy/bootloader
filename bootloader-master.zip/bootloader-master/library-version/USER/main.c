#include "BSP.h"
#include <stdio.h>
#include "delay.h"
#include "queue_loop.h"

typedef void (*pFunction)(void);//����ָ��
pFunction Jump_To_Application;//����һ������ָ�����

void jump2app(void)
{
    Jump_To_Application = (pFunction)(*(vu32*)(IAPSTART + 4));
	__set_MSP(*(vu32*) IAPSTART);
	Jump_To_Application();
}


int main(void)
{
	char flag = 1;
	int i;
	short res = 0x00;
	RCC_Configuration();
	NVIC_Configuration();
	GPIO_Configuration();
	USART_Configuration();
	delay_init(72);
	GPIO_ResetBits(GPIOC,GPIO_Pin_13);
	for(i=0; i < MAXSIZE; i++)
		uart_data[i] = 0xff;

	while(flag)
	{
		if(/*!GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0) || */!GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_2))//if PB0 is high
		{
			flag = 0;
//			for(i=0; i < MAXSIZE; i++){
//				USART_SendData(USART1, uart_data[i]); 
//				while((USART1->SR & USART_FLAG_TC) == RESET);	
//			}

		    //1 erase the flash
			FlashAllErase();
			//2 program the flash
			FlashProgram();

			for(i = 0;i < MAXSIZE; i += 2){
			res = Program_Flash_ReadHalfWord(0x8003000+i);
			USART_SendData(USART1, res >> 8);
			while((USART1->SR & USART_FLAG_TC) == RESET);
			USART_SendData(USART1, res & 0xff);
			while((USART1->SR & USART_FLAG_TC) == RESET);
			}

			jump2app();
//			GPIO_SetBits(GPIOC,GPIO_Pin_13);
//			delay_ms(500);
//			GPIO_ResetBits(GPIOC,GPIO_Pin_13);
//			delay_ms(500);
//			GPIO_SetBits(GPIOC,GPIO_Pin_13);
//			delay_ms(500);

			GPIO_SetBits(GPIOB,GPIO_Pin_5);
			delay_ms(500);
			GPIO_ResetBits(GPIOB,GPIO_Pin_5);
			delay_ms(500);
			GPIO_SetBits(GPIOB,GPIO_Pin_5);
			delay_ms(500);
		}

		if(flag == 0)
		{
		    //jump2app();
		}
//		GPIO_SetBits(GPIOC,GPIO_Pin_13);
//		delay_ms(100);
//		GPIO_ResetBits(GPIOC,GPIO_Pin_13);
//		delay_ms(100);

		GPIO_SetBits(GPIOB,GPIO_Pin_5);
		delay_ms(100);
		GPIO_ResetBits(GPIOB,GPIO_Pin_5);
		delay_ms(100);

	}   
}

