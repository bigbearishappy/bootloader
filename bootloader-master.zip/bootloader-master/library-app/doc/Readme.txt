20161018
V1.0.0 ok
operation step:
1 use uartassist to sent the *.bin file to the MCU
2 push the button down 